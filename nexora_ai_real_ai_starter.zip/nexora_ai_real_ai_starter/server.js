import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { InferenceClient } from "@huggingface/inference";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "8mb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: "draft-7", legacyHeaders: false }));
app.use(express.static(__dirname));

const PORT = Number(process.env.PORT || 3000);
const HF_TOKEN = process.env.HF_TOKEN;
const MODEL_ID = process.env.MODEL_ID || "Qwen/Qwen2.5-7B-Instruct";

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(HF_TOKEN), provider: "Hugging Face Inference Providers" });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!HF_TOKEN) {
      return res.status(503).json({ error: "Server setup incomplete: add HF_TOKEN to your private .env file." });
    }
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message && !req.body?.imageData) return res.status(400).json({ error: "Please enter a message." });
    if (message.length > 12000) return res.status(413).json({ error: "Message is too long (maximum 12,000 characters)." });

    // The current endpoint is text-only. Do not pretend an image was analyzed.
    if (req.body?.imageData) {
      return res.status(501).json({ error: "Photo upload UI is present, but image understanding is not enabled in this starter. A vision-capable model and compatible provider must be configured first." });
    }

    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-12) : [];
    const safeHistory = history
      .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));

    const client = new InferenceClient(HF_TOKEN);
    const messages = [
      { role: "system", content: "You are Nexora AI, a helpful, honest multilingual assistant. The product was created by Yaseen, its founder. If asked who created Nexora, say it was created by Yaseen. Be clear about uncertainty and never claim to have performed actions you have not performed." },
      ...safeHistory,
      { role: "user", content: message }
    ];
    const completion = await client.chatCompletion({
      model: MODEL_ID,
      messages,
      max_tokens: 700,
      temperature: 0.7
    });
    const reply = completion.choices?.[0]?.message?.content;
    if (!reply) throw new Error("The model returned no text.");
    res.json({ reply, model: MODEL_ID });
  } catch (err) {
    console.error("Chat provider error:", err?.message || err);
    res.status(502).json({
      error: "AI provider request failed. Check your model access, available provider credits, model ID, and server logs."
    });
  }
});

app.listen(PORT, () => {
  console.log(`Nexora AI is running at http://localhost:${PORT}`);
  console.log(`Model: ${MODEL_ID}`);
});
