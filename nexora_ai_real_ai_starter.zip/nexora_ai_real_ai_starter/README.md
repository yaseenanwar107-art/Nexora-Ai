# Nexora AI — real AI starter (v0.3)

This starter keeps the Nexora interface and adds a Node.js backend that calls a Hugging Face Inference Provider model for **text chat**.

## Important limits
- This is a starter, not a deployed public website. The AI request will not work until you install dependencies and set a private API token.
- Image upload remains a UI preview only. The backend explicitly refuses to pretend it analyzed a photo. Vision needs a compatible model/provider and a follow-up implementation.
- Video generation is not implemented. It needs a real video API, provider access, and may cost money.
- Provider availability, model support, quotas, and prices can change. Check your account's current provider credits before use.
- Never share your token in a chat, screenshot, or public code repository.

## What is needed
A computer with Node.js 20+ installed, internet, and a Hugging Face account/token. No laptop? You can still keep this ZIP safe and use a trusted computer later; deploying it publicly requires a server host.

## Setup (computer)
1. Extract this ZIP into a folder.
2. Install Node.js 20 or newer from the official Node.js website.
3. Open a terminal in this folder and run:
   `npm install`
4. Copy `.env.example` to a new file named `.env`.
5. Open `.env` and replace the example token with your private Hugging Face token. Keep `.env` private.
6. Run:
   `npm start`
7. Open `http://localhost:3000` in your browser.

If the model ID is not available through your selected inference provider, choose a text-generation/chat-completion model supported by a provider in your Hugging Face account and update `MODEL_ID` in `.env`.

## API health check
Open `http://localhost:3000/api/health`. `configured` should be `true` after you set `HF_TOKEN`.

## Next upgrades
1. Add a proper vision endpoint and send image bytes safely to a compatible vision model.
2. Add authentication and per-user limits before public deployment.
3. Connect a real video-generation provider only after checking pricing and terms.
4. Add privacy notice, delete-chat controls, error handling, and abuse protection before inviting public users.

Creator attribution is set in the assistant's system instruction as “Yaseen”. This influences answers but is not tamper-proof identity verification.
